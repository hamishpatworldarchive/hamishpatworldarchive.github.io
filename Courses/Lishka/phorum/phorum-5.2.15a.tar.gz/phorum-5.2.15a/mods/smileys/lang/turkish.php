<?php
$PHORUM["DATA"]["LANG"]["mod_smileys"] = array(
    'smiley'        => 'Smiley Ekle',
    'subjectsmiley' => 'Konu ba�l���na smiley ekle',
    'smileys help'  => 'Smiley Yard�m',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Mesaj�mda Smiley kullanma'
);
?>
