<?php
$PHORUM["DATA"]["LANG"]["mod_smileys"] = array(
    'smiley'        => 'Ins�rer un �moticon',
    'subjectsmiley' => 'Ins�rer un �moticon dans le sujet',
    'smileys help'  => 'Aide sur les Smileys',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Disable smileys for this message'
);
?>
